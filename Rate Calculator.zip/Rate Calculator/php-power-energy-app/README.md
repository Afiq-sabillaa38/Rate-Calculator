# PHP Power Energy App

This project is a simple PHP application that calculates power, energy, and total charge based on user input. It utilizes basic formulas from electrical engineering to perform these calculations.

## Project Structure

```
php-power-energy-app
├── src
│   ├── calculatePower.php
│   ├── calculateEnergy.php
│   ├── calculateTotalCharge.php
│   └── config.php
├── public
│   ├── index.php
│   └── css
│       └── bootstrap.min.css
├── .gitignore
├── composer.json
└── README.md
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd php-power-energy-app
   ```

3. Install dependencies using Composer:
   ```
   composer install
   ```

## Usage

1. Open `public/index.php` in your web browser.
2. Input the required values for voltage, current, power, hours, and rate.
3. The application will display the calculated power, energy, and total charge.

## Functions

- **calculatePower($voltage, $current)**: Calculates power in watts using the formula:
  ```
  Power (Wh) = Voltage (V) * Current (A)
  ```

- **calculateEnergy($power, $hours)**: Calculates energy in kilowatt-hours using the formula:
  ```
  Energy (kWh) = Power * Hour * 1000
  ```

- **calculateTotalCharge($energy, $rate)**: Calculates the total charge based on energy consumed and the current rate using the formula:
  ```
  Total = Energy(kWh) * (current rate/100)
  ```

## License

This project is licensed under the MIT License. See the LICENSE file for details.