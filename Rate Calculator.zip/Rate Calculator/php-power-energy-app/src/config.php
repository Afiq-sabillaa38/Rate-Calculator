<?php
define('CURRENT_RATE', 50); // Change 50 to your actual rate
// Additional configuration settings can be added here
?>