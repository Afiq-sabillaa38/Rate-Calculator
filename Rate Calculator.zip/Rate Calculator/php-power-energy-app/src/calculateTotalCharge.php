<?php
function calculateTotalCharge($energy, $rate) {
    return $energy * ($rate / 100);
}
?>