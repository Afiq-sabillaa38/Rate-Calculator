<?php
function calculatePower($voltage, $current) {
    return $voltage * $current;
}
?>